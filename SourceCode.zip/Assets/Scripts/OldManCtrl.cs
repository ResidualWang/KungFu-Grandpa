﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OldManCtrl : MonoBehaviour
{
    public static OldManCtrl _oldManCtrl;
    public Transform point;
    public Vector3 awakePoint;
    public bool isRot;
    public bool isMove;

    void Awake()
    {
        _oldManCtrl = this;
        point = transform.parent;
        awakePoint = point.position;
    }

    void Start()
    {
        point = transform.parent;
    }


    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.transform.tag == "Groud")
        {
            Stop();
            TrainManager._trainManager.xp -= TrainManager._trainManager.xp * 0.15f;
            MusicManager._musicManager.crash.Play();
        }
    }
    
    void FixedUpdate()
    {
        if(TrainManager._trainManager.isTraining)
        {
            //左右旋转
            if(Input.GetKey(KeyCode.A))
            {
                point.Rotate(new Vector3(0,0,1) * 66f * Time.deltaTime ,Space.Self);
                isRot = true;
            }else if(Input.GetKey(KeyCode.D))
            {
                point.Rotate(new Vector3(0,0,-1)  * 66f * Time.deltaTime,Space.Self);
                isRot = true;
            }else
            {
                isRot = false;
            }

            //左右移动
            if(Input.GetKey(KeyCode.LeftArrow))
            {
                point.Translate(new Vector3(-1,0,0) * 3.6f * Time.deltaTime,Space.World);
                isMove = true;
            }
            else if(Input.GetKey(KeyCode.RightArrow))
            {
                point.Translate(new Vector3(1,0,0) * 3.6f * Time.deltaTime,Space.World);
                isMove = true;
            }else
            {
                isMove = false;
            }
        }

        if(TrainManager._trainManager.isTraining)
        {
            if(!isRot)
            {
                if(point.rotation.z == 0)
                {
                    point.localEulerAngles = Vector3.Lerp(new Vector3(CheckAngle(point.localEulerAngles.x),CheckAngle(point.localEulerAngles.y),CheckAngle(point.localEulerAngles.z)),new Vector3(0,0,Random.Range(-1,1)),0.3f * Time.deltaTime);
                }

                if(point.rotation.z > 0)
                {
                    point.Rotate(new Vector3(0,0,1) * 66f * Time.deltaTime ,Space.Self);
                }

                if(point.rotation.z < 0)
                {
                    point.Rotate(new Vector3(0,0,-1)  * 66f * Time.deltaTime,Space.Self);
                }
            }

            if(!isMove)
            {
                if(point.position.x > -4.6f && !Input.GetKey(KeyCode.LeftArrow))
                {
                    point.Translate(new Vector3(1,0,0) * 3.6f * Time.deltaTime,Space.World);
                }
                else if(point.position.x <= -4.6f && !Input.GetKey(KeyCode.RightArrow))
                {
                    point.Translate(new Vector3(-1,0,0) * 3.6f * Time.deltaTime,Space.World);
                }
            }

        }
        
    }

    public float CheckAngle(float value)  // 将大于180度角进行以负数形式输出
    {
        float angle = value - 180;  

        if (angle > 0)
        {
            return angle - 180;
        }

        if (value == 0)
        {
            return 0;
        }

        return angle + 180;
    }

    public void Stop()
    {
        TrainManager._trainManager.isTraining = false;
        point.position = awakePoint;
        point.localEulerAngles = Vector3.zero;
    }
}
