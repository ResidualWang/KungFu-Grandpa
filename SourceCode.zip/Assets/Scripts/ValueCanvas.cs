﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ValueCanvas : MonoBehaviour
{
    public int levelPoint;
    
}
