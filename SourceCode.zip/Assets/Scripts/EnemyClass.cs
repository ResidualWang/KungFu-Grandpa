﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyClass : MonoBehaviour
{
    public int maxHp;    //最大生命值
    public int nowHp;    //当前生命值

    public int str;     //力量
    public int agi;     //敏捷
    public int con;     //体质
    public int def;     //坚韧
    public int hit;     //命中
    public int cra;     //暴击

    void Awake()
    {
        UpdateInfo();
    }

    void Update()
    {
        //死亡
        if(nowHp <= 0)
        {
            FightManager._fightManager.enemyClass = null;
            Destroy(gameObject);
        }
    }

    //承受伤害
    public void GitHit(int value)
    {
        nowHp -= (value - (int)(def / 2f) > 0)?value - (int)(def / 2f):1;
    }

    //造成伤害
    public void GiveHit()
    {
        StartCoroutine("Act");
        //先判定命中
        if(Random.Range(0,11) < ((hit - OldManValue._oldManValue.agi / 2f > 0)?hit - OldManValue._oldManValue.agi / 2f:3))
        {   
            MusicManager._musicManager.miss.Play();
            OldManValue._oldManValue.StartCoroutine("Miss");
        }else
        {
            //再判断暴击
            bool isCra = Random.Range(0,11) < cra / 2f;
            //给伤害
            if(isCra)
            {
                //暴击
                OldManValue._oldManValue.GitHit(str * 2);
                MusicManager._musicManager.cra.Play();

            }else
            {
                //非暴击
                OldManValue._oldManValue.GitHit(str);
                MusicManager._musicManager.hit.Play();
            }
        }
        
    }

    IEnumerator Act()
    {
        transform.Translate(new Vector3(-1,0,0));
        yield return new WaitForSeconds(0.16f);
        transform.Translate(new Vector3(1,0,0));
    }

    IEnumerator Miss()
    {
        transform.Translate(new Vector3(1,0,0));
        yield return new WaitForSeconds(0.16f);
        transform.Translate(new Vector3(-1,0,0));
    }

    public void UpdateInfo()
    {
        switch (LevelCtrl._levelCtrl.level)
        {
            case 1:
            str = Random.Range(1,4);
            agi = Random.Range(1,4);
            con = Random.Range(3,5);
            def = Random.Range(1,4);
            hit = Random.Range(1,4);
            cra = Random.Range(1,4);
            break;

            case 2:
            str = Random.Range(3,8);
            agi = Random.Range(3,8);
            con = Random.Range(5,10);
            def = Random.Range(3,8);
            hit = Random.Range(3,8);
            cra = Random.Range(3,8);
            break;

            case 3:
            str = Random.Range(5,10);
            agi = Random.Range(5,10);
            con = Random.Range(5,10);
            def = Random.Range(5,10);
            hit = Random.Range(5,10);
            cra = Random.Range(5,10);
            break;
            
            default:
            break;
        }
        maxHp = con * 5;
        nowHp = maxHp;
    }
}
