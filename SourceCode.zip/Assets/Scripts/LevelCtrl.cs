﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelCtrl : MonoBehaviour
{
    public static LevelCtrl _levelCtrl;
    public int level;
    public int maxEnemy;
    public int nowEnemy;

    void Awake()
    {
        _levelCtrl = this;        
    }

    
    void Update()
    {
        switch (level)
        {
            case 1:
            maxEnemy = 3;
            break;

            case 2:
            maxEnemy = 5;
            break;

            case 3:
            maxEnemy = 7;
            break;


            default:
            break;
        }   
    }

    public void ChoiceLevel(int level)
    {
        nowEnemy = 0;
        this.level = level;
        GetComponent<CanvasGroup>().alpha = 0;
        GetComponent<CanvasGroup>().interactable = false;
        GetComponent<CanvasGroup>().blocksRaycasts = false;
        //打开战斗UI
        FightManager._fightManager.GetComponent<CanvasGroup>().alpha = 1;
        FightManager._fightManager.GetComponent<CanvasGroup>().interactable = true;
        FightManager._fightManager.GetComponent<CanvasGroup>().blocksRaycasts = true;
        FightManager._fightManager.isFight = true;
        OldManValue._oldManValue.nowHp = OldManValue._oldManValue.maxHp;
    }
}
