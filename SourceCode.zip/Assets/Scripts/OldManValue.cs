﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OldManValue : MonoBehaviour
{
    public static OldManValue _oldManValue;
    public int maxHp;    //最大生命值
    public int nowHp;    //当前生命值

    public int str;     //力量
    public int agi;     //敏捷
    public int con;     //体质
    public int def;     //坚韧
    public int hit;     //命中
    public int cra;     //暴击

    void Awake()
    {
        _oldManValue = this;
        str = 3;
        agi = 3;
        con = 5;
        def = 0;
        hit = 3;
        cra = 0;
        maxHp = con * 5;
        nowHp = maxHp;
    }


    void Update()
    {
        maxHp = con * 5;

        //死亡
        if(FightManager._fightManager.isFight && nowHp <= 0)
        {
            Destroy(FightManager._fightManager.enemyClass.gameObject);
            FightManager._fightManager.enemyClass = null;
            FightManager._fightManager.BackToTrain();
        }
    }

    //承受伤害
    public void GitHit(int value)
    {
        nowHp -= (value - (int)(def / 2f) > 0)?value - (int)(def / 2f):1;
    }

    //造成伤害
    public void GiveHit(EnemyClass enemyClass)
    {
        StartCoroutine("Act");
        //先判定命中
        if(Random.Range(0,11) < ((hit - enemyClass.agi / 2f > 0)?hit - enemyClass.agi / 2f:3))
        {
            MusicManager._musicManager.miss.Play();
            enemyClass.StartCoroutine("Miss");
            return;
        }else
        {
            //再判断暴击
            bool isCra = Random.Range(0,11) < cra / 2;
            //给伤害
            if(isCra)
            {
                //暴击
                enemyClass.GitHit(str * 2);
                MusicManager._musicManager.cra.Play();

            }else
            {
                //非暴击
                enemyClass.GitHit(str);
                MusicManager._musicManager.hit.Play();
            }
        }
        
    }

    IEnumerator Act()
    {
        transform.Translate(new Vector3(1,0,0));
        yield return new WaitForSeconds(0.16f);
        transform.Translate(new Vector3(-1,0,0));
    }

    IEnumerator Miss()
    {
        transform.Translate(new Vector3(1,0,0));
        yield return new WaitForSeconds(0.16f);
        transform.Translate(new Vector3(-1,0,0));
    }
}
