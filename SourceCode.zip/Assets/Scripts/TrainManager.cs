﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TrainManager : MonoBehaviour
{
    public static TrainManager _trainManager;
    public bool isTraining; //是否正在训练
    public Button[] addButtons;//升级按钮集合
    public Slider slider;   //经验条
    public Text sliderText; //经验文字显示
    public Text skillPointCount;//技能点
    public int levelPoint;  //技能点
    public float xp;        //经验
    public float maxXp;     //升级所需经验


    void Awake()
    {
        _trainManager = this;
        maxXp = 50;
    }

    void Start()
    {
        slider = transform.Find("ValuePlane").Find("XPSlider").GetComponent<Slider>();
        sliderText = transform.Find("ValuePlane").Find("XPText").GetComponent<Text>();
        skillPointCount = transform.Find("ValuePlane").Find("SkillPointText").GetComponent<Text>();
    }
    
    void Update()
    {
        //经验条
        slider.value = xp / maxXp;
        sliderText.text = (int)(xp) + "/" + maxXp.ToString();
        skillPointCount.text = levelPoint.ToString();

        //获取经验
        if(isTraining)
        {
            xp += 5f * Time.deltaTime;
        }

        //升级
        if(xp > maxXp)
        {
            xp = 0;
            maxXp += 10;
            levelPoint++;
        }

        //数值显示
        addButtons[0].transform.parent.Find("ValueCount").GetComponent<Text>().text = OldManValue._oldManValue.str.ToString();
        addButtons[1].transform.parent.Find("ValueCount").GetComponent<Text>().text = OldManValue._oldManValue.agi.ToString();
        addButtons[2].transform.parent.Find("ValueCount").GetComponent<Text>().text = OldManValue._oldManValue.con.ToString();
        addButtons[3].transform.parent.Find("ValueCount").GetComponent<Text>().text = OldManValue._oldManValue.def.ToString();
        addButtons[4].transform.parent.Find("ValueCount").GetComponent<Text>().text = OldManValue._oldManValue.hit.ToString();
        addButtons[5].transform.parent.Find("ValueCount").GetComponent<Text>().text = OldManValue._oldManValue.cra.ToString();

        //按钮是否可用
        foreach (Button item in addButtons)
        {        
            if(levelPoint > 0)
            {
                item.interactable = true;
            }else
            {
                item.interactable = false;
            }
        }

        //等级限制
        if(OldManValue._oldManValue.str >= 10)
        addButtons[0].interactable = false;
        if(OldManValue._oldManValue.agi >= 10)
        addButtons[1].interactable = false;
        if(OldManValue._oldManValue.con >= 10)
        addButtons[2].interactable = false;
        if(OldManValue._oldManValue.def >= 10)
        addButtons[3].interactable = false;
        if(OldManValue._oldManValue.hit >= 10)
        addButtons[4].interactable = false;
        if(OldManValue._oldManValue.cra >= 10)
        addButtons[5].interactable = false;
    }

    //升级按钮
    public void AddPoint(string value)
    {
        switch (value)
        {
            case "str":
            OldManValue._oldManValue.str++;
            break;

            case "agi":
            OldManValue._oldManValue.agi++;
            break;

            case "con":
            OldManValue._oldManValue.con++;
            break;

            case "def":
            OldManValue._oldManValue.def++;
            break;

            case "hit":
            OldManValue._oldManValue.hit++;
            break;

            case "cra":
            OldManValue._oldManValue.cra++;
            break;

            default:
            break;
        }
        levelPoint--;
    }
    
    //开始训练
    public void StartTrain()
    {
        isTraining = !isTraining;
        if(!isTraining)
        OldManCtrl._oldManCtrl.Stop();
    }

    //跳转至战斗
    public void StartFight()
    {
        if(!isTraining)
        {
            //移动摄像机
            Camera.main.transform.position = new Vector3(30,0,-10);
            //隐藏训练UI
            GetComponent<CanvasGroup>().alpha = 0;
            GetComponent<CanvasGroup>().interactable = false;
            GetComponent<CanvasGroup>().blocksRaycasts = false;
            //打开关卡UI
            LevelCtrl._levelCtrl.GetComponent<CanvasGroup>().alpha = 1;
            LevelCtrl._levelCtrl.GetComponent<CanvasGroup>().interactable = true;
            LevelCtrl._levelCtrl.GetComponent<CanvasGroup>().blocksRaycasts = true;
        }
    }
}
