﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FightManager : MonoBehaviour
{
    public static FightManager _fightManager;
    public bool isFight;            //是否正在交战
    public GameObject[] enemys;     //敌人数组
    public EnemyClass enemyClass;   //当前敌人

    public Slider oldManSlider;     //大爷血条
    public Slider enemySlider;      //敌人血条
    public Text oldManText;
    public Text enemyText; 
    public Text enemyCount;       //敌人剩余数量

    public Transform enemyTrans;   //敌人生成位置

    public float oldManWait;        //大爷攻击间隔
    public float enemyWait;         //当前敌人攻击间隔

    public float oldManNow;         //大爷当前时间
    public float enemyNow;          //敌人当前时间

    void Awake()
    {
        _fightManager = this;  
        enemys = Resources.LoadAll<GameObject>("Enemys");
    }

    void Start()
    {
        oldManSlider = transform.Find("OldManSlider").GetComponent<Slider>();
        enemySlider = transform.Find("EnemySlider").GetComponent<Slider>();
        oldManText = transform.Find("OldManText").GetComponent<Text>();
        enemyText = transform.Find("EnemyText").GetComponent<Text>();
        enemyCount = transform.Find("EnemyCount").GetComponent<Text>();
        enemyTrans = transform.parent.Find("EnemyTrans");
        
    }

    void Update()
    {
        if(isFight)
        {
            //敌人为null的时候
            if(enemyClass == null)
            {
                //生成敌人
                if(LevelCtrl._levelCtrl.nowEnemy < LevelCtrl._levelCtrl.maxEnemy)
                {
                    GameObject a = Instantiate(enemys[Random.Range(0,enemys.Length)],enemyTrans);
                    enemyClass = a.GetComponent<EnemyClass>();
                    LevelCtrl._levelCtrl.nowEnemy++;
                }
                else if(LevelCtrl._levelCtrl.nowEnemy == LevelCtrl._levelCtrl.maxEnemy)
                {
                    //结束战斗
                    BackToTrain();
                }
            }

            //自动交战
            if(enemyClass != null)
            {
                oldManWait  = 1.6f - 0.1f * OldManValue._oldManValue.agi;
                enemyWait = 1.6f - 0.1f * enemyClass.agi;
                oldManNow += Time.deltaTime;
                enemyNow += Time.deltaTime;
                if(oldManNow >= oldManWait)
                {
                    OldManValue._oldManValue.GiveHit(enemyClass);
                    oldManNow = 0;
                }
                if(enemyNow >= enemyWait)
                {
                    enemyClass.GiveHit();
                    enemyNow = 0;
                }
            }

            //UI界面
            if(enemyClass != null)
            {
                oldManSlider.value = OldManValue._oldManValue.nowHp * 1f / OldManValue._oldManValue.maxHp * 1f;
                enemySlider.value = enemyClass.nowHp *1f / enemyClass.maxHp * 1f;
                oldManText.text = OldManValue._oldManValue.nowHp.ToString() + "/" + OldManValue._oldManValue.maxHp.ToString();
                enemyText.text = enemyClass.nowHp.ToString() + "/" + enemyClass.maxHp.ToString();
                enemyCount.text = (LevelCtrl._levelCtrl.maxEnemy - LevelCtrl._levelCtrl.nowEnemy).ToString();
            }
        }
    }

    public void BackToTrain()
    {
        Camera.main.transform.position = new Vector3(0,0,-10);
        isFight = false;
        LevelCtrl._levelCtrl.nowEnemy = 0;
        //关闭战斗UI
        GetComponent<CanvasGroup>().alpha = 0;
        GetComponent<CanvasGroup>().interactable = false;
        GetComponent<CanvasGroup>().blocksRaycasts = false;
        //打开训练UI
        TrainManager._trainManager.GetComponent<CanvasGroup>().alpha = 1;
        TrainManager._trainManager.GetComponent<CanvasGroup>().interactable = true;
        TrainManager._trainManager.GetComponent<CanvasGroup>().blocksRaycasts = true;
    }
}
