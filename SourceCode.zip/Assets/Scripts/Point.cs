﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Point : MonoBehaviour
{
    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.transform.tag == "Wall")
        {
            MusicManager._musicManager.crash.Play();
            OldManCtrl._oldManCtrl.Stop();
        }
    }
}
