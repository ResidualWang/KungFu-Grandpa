﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropItemManager : MonoBehaviour
{
    public GameObject [] dropItems;
    public float waitTime;
    public float nowTime;

    void Awake()
    {
        waitTime = 2f;
        dropItems = Resources.LoadAll<GameObject>("DropItems");
    }
    
    void Update()
    {
        if(TrainManager._trainManager.isTraining)
        {
            nowTime += Time.deltaTime;
            if(nowTime > waitTime)
            {
                nowTime -= waitTime;
                Instantiate(dropItems[Random.Range(0,dropItems.Length)],new Vector3(transform.position.x + Random.Range(4,-4),transform.position.y,transform.position.z),Quaternion.Euler(0,0,Random.Range(0,360)));
            }
        }
        
    }
}
