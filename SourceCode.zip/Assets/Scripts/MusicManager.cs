﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicManager : MonoBehaviour
{
    public static MusicManager _musicManager;
    public AudioSource BGM;
    public AudioSource FightBGM;
    public AudioSource hit;
    public AudioSource cra;
    public AudioSource miss;
    public AudioSource crash;

    void Awake()
    {
        _musicManager = this;
    }

    void Start()
    {
        BGM = transform.Find("BGM").GetComponent<AudioSource>();
        FightBGM = transform.Find("FightBGM").GetComponent<AudioSource>();
        hit = transform.Find("HIT").GetComponent<AudioSource>();
        cra = transform.Find("CRA").GetComponent<AudioSource>();
        miss = transform.Find("Miss").GetComponent<AudioSource>();
        crash = transform.Find("Crash").GetComponent<AudioSource>();
    }

    void Update()
    {
        
    }
}
