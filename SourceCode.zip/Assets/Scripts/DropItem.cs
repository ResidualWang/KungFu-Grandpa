﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropItem : MonoBehaviour
{

    void Update()
    {
        transform.Rotate(0,0,5);
        if(!TrainManager._trainManager.isTraining)
        Destroy(gameObject); 
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        Destroy(gameObject);       
    }
}
